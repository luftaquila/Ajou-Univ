package external_input;
import external_input.external_input;

public class hdmi extends external_input{
	// 구현
}
