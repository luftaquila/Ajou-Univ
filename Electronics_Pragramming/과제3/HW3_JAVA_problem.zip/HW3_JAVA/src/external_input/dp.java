package external_input;
import external_input.external_input;

public class dp extends external_input{
	// 구현
}
