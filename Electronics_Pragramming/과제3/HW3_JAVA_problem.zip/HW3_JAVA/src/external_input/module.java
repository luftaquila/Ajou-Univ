package external_input;

interface module {
	public abstract void checkInput_type();
	public abstract void print();
}
