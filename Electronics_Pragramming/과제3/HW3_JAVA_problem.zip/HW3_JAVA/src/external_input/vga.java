package external_input;
import external_input.external_input;

public class vga extends external_input{
	// 구현
}
